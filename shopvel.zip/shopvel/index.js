/*!
 * shopvel
 * MIT Licensed
 */

'use strict';

var mongoose = require('mongoose');
//var express	= require('express');
//var router	= express.Router();
var model = {};
var routes = [];

var shopvel = {
	registerContentType : (name, args) => {
		model[name] = mongoose.Schema(args);
		routes.push(name);
	},
	getContent : name => mongoose.model(name, model[name])
};

exports = module.exports = shopvel;

exports.router = router => {
	for(let i = 0; i < routes.length; i++ ) {
		router.get('/'+routes[i], (req, res) => {
			shopvel.getContent(routes[i]).find({}, (err, p) => {
				if (err) res.send({ message: err });
				res.json({ [routes[i]] : p });
			});
		});
	}
	return router;
}
